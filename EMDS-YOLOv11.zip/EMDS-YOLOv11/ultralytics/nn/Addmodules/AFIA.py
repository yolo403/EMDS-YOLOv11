import torch
import torch.nn as nn
import torch.nn.functional as F

__all__ = ['AFIA',  'C2PSA_AFIA']


class ChannelShuffle(nn.Module):
    def __init__(self, groups):
        super().__init__()
        self.groups = groups

    def forward(self, x):
        b, c, h, w = x.size()
        channels_per_group = c // self.groups
        # reshape
        x = x.view(b, self.groups, channels_per_group, h, w)
        # transpose
        x = x.transpose(1, 2).contiguous()
        # flatten
        x = x.view(b, -1, h, w)

        return x


class AFIA(nn.Module):
    def __init__(self, in_channels, groups):
        super().__init__()

        self.layer_norm = nn.LayerNorm(in_channels)  # Assuming layer norm is applied over channels

        self.conv1x1_q = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.deconv3x3_q = nn.ConvTranspose2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1)

        self.conv1x1_k = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.deconv3x3_k = nn.ConvTranspose2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1)

        self.conv1x1_v = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.deconv3x3_v = nn.ConvTranspose2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1)

        self.channel_shuffle = ChannelShuffle(groups)

        self.stacked_conv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1),
        )

        self.conv1x1_out = nn.Conv2d(in_channels, in_channels, kernel_size=1)

        self.layer_norm2 = nn.LayerNorm(in_channels)

    def depthwise_spatial_attention(self, Q, K):
        """Calculates the Depthwise Spatial Attention Map between Q and K.
         Args:
          Q: Tensor of shape (B, C, H, W)
          K: Tensor of shape (B, C, H, W)
         Returns:
            A spatial attention map with shape (B, H, W)
        """

        B, C, H, W = Q.shape
        Q = Q.permute(0, 2, 3, 1).reshape(B, H * W, C)  # B, HW, C
        K = K.permute(0, 2, 3, 1).reshape(B, H * W, C)  # B, HW, C

        attention_map = torch.matmul(Q, K.transpose(1, 2))  # B, HW, HW

        attention_map = F.softmax(attention_map / (C ** 0.5), dim=-1)  # B, HW, HW

        return attention_map

    def spatial_wise_self_attention(self, V, attention_map):
        """
        Apply spatial-wise self-attention to value feature map
         Args:
            V: Tensor of shape (B, C, H, W)
            attention_map: Attention map with shape (B, H, W, HW)
          Return:
             weighted V
        """

        B, C, H, W = V.shape
        V = V.permute(0, 2, 3, 1).reshape(B, H * W, C)  # B, HW, C

        weighted_V = torch.matmul(attention_map, V)

        weighted_V = weighted_V.reshape(B, H, W, C).permute(0, 3, 1, 2)

        return weighted_V

    def forward(self, x):
        residual = x
        x = x.permute(0, 2, 3, 1)  # B,H,W,C
        x = self.layer_norm(x).permute(0, 3, 1, 2)  # B,C,H,W

        # Q branch
        Q = self.conv1x1_q(x)
        Q = self.deconv3x3_q(Q)

        # K branch
        K = self.conv1x1_k(x)
        K = self.deconv3x3_k(K)

        # V branch
        V = self.conv1x1_v(x)
        V = self.deconv3x3_v(V)

        # Channel Shuffle
        x = self.channel_shuffle(x)

        # DSA
        attention_map = self.depthwise_spatial_attention(Q, K)

        # SSA
        out = self.spatial_wise_self_attention(V, attention_map)

        # Apply weights
        out = F.relu(out)

        # 1x1 Conv out
        out = self.conv1x1_out(out)

        # Add and output
        out = out + self.stacked_conv(x)
        out = out + residual

        out = out.permute(0, 2, 3, 1)
        out = self.layer_norm2(out).permute(0, 3, 1, 2)

        return out

def autopad(k, p=None, d=1):  # kernel, padding, dilation
    """Pad to 'same' shape outputs."""
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]  # actual kernel-size
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]  # auto-pad
    return p


class Conv(nn.Module):
    """Standard convolution with args(ch_in, ch_out, kernel, stride, padding, groups, dilation, activation)."""

    default_act = nn.SiLU()  # default activation

    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, d=1, act=True):
        """Initialize Conv layer with given arguments including activation."""
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p, d), groups=g, dilation=d, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = self.default_act if act is True else act if isinstance(act, nn.Module) else nn.Identity()

    def forward(self, x):
        """Apply convolution, batch normalization and activation to input tensor."""
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        """Perform transposed convolution of 2D data."""
        return self.act(self.conv(x))

class PSABlock(nn.Module):
    def __init__(self, c, attn_ratio=0.5, num_heads=4, shortcut=True) -> None:
        """Initializes the PSABlock with attention and feed-forward layers for enhanced feature extraction."""
        super().__init__()

        self.attn = AFIA(c, 4)
        self.ffn = nn.Sequential(Conv(c, c * 2, 1), Conv(c * 2, c, 1, act=False))
        self.add = shortcut

    def forward(self, x):
        """Executes a forward pass through PSABlock, applying attention and feed-forward layers to the input tensor."""
        x = x + self.attn(x) if self.add else self.attn(x)
        x = x + self.ffn(x) if self.add else self.ffn(x)
        return x


class C2PSA_AFIA(nn.Module):
    """
    C2PSA module with attention mechanism for enhanced feature extraction and processing.

    This module implements a convolutional block with attention mechanisms to enhance feature extraction and processing
    capabilities. It includes a series of PSABlock modules for self-attention and feed-forward operations.

    Attributes:
        c (int): Number of hidden channels.
        cv1 (Conv): 1x1 convolution layer to reduce the number of input channels to 2*c.
        cv2 (Conv): 1x1 convolution layer to reduce the number of output channels to c.
        m (nn.Sequential): Sequential container of PSABlock modules for attention and feed-forward operations.

    Methods:
        forward: Performs a forward pass through the C2PSA module, applying attention and feed-forward operations.

    Notes:
        This module essentially is the same as PSA module, but refactored to allow stacking more PSABlock modules.


    """

    def __init__(self, c1, c2, n=1, e=0.5):
        """Initializes the C2PSA module with specified input/output channels, number of layers, and expansion ratio."""
        super().__init__()
        assert c1 == c2
        self.c = int(c1 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv(2 * self.c, c1, 1)

        self.m = nn.Sequential(*(PSABlock(self.c, attn_ratio=0.5, num_heads=self.c // 64) for _ in range(n)))

    def forward(self, x):
        """Processes the input tensor 'x' through a series of PSA blocks and returns the transformed tensor."""
        a, b = self.cv1(x).split((self.c, self.c), dim=1)
        b = self.m(b)
        return self.cv2(torch.cat((a, b), 1))


if __name__ == "__main__":
    # Generating Sample image
    image_size = (1, 64, 240, 240)
    image = torch.rand(*image_size)

    # Model
    mobilenet_v1 = C2PSA_AFIA(64, 64)

    out = mobilenet_v1(image)
    print(out.size())

